<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>
            Tables
            <small>
                <i class="ace-icon fa fa-angle-double-right"></i>
                Static &amp; Dynamic Tables
            </small>
        </h1>
    </div>

    <div class="container-fluid">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-xs-12">
                <table id="simple-table" class="table  table-bordered table-hover">
                    <thead>
                    <tr>
                        <th class="center">
                            <label class="pos-rel">
                                <input type="checkbox" class="ace">
                                <span class="lbl"></span>
                            </label>
                        </th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th class="hidden-480">Email</th>

                        <th>
                            Address
                        </th>
                        <th class="hidden-480">Product</th>

                        <th>Price</th>
                        <th></th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="center">
                                <label class="pos-rel">
                                    <input type="checkbox" class="ace">
                                    <span class="lbl"></span>
                                </label>
                            </td>

                            <td class="center">
                                <?php echo e($customer->name); ?>

                            </td>

                            <td>
                                <?php echo e($customer->phone); ?>

                            </td>
                            <td><?php echo e($customer->email); ?></td>
                            <td class="hidden-480"><?php echo e($customer->adddress); ?></td>
                            <td><?php echo e($customer->purchase_info); ?></td>

                            <td class="hidden-480">
                                <span class="label label-sm label-warning"><?php echo e($customer->price); ?></span>
                            </td>

                            <td>
                                <div class="hidden-sm hidden-xs" style="display:flex;">
                                    <a href="<?php echo e(route('customer.edit',['customer'=>$customer->id])); ?>"
                                       class="btn btn-xs btn-success">
                                        <i class="ace-icon fa fa-edit bigger-120"></i>
                                    </a>
                                    <form method="post" class="d-inline"
                                          action="<?php echo e(route('customer.destroy',['customer'=>$customer->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-xs btn-danger" type="submit"
                                                onclick="return confirm('Are you sure?')">
                                            <i class="ace-icon fa fa-trash bigger-120"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!-- /.span -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shuvo./Documents/ace_admin_template/resources/views/customer/index.blade.php ENDPATH**/ ?>